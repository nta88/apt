# CHANGELOG

## 0.1.1 (2020-02-18)

* Fix release config
* Add release instructions

## 0.1.0 (2020-02-18)

* Initial beta release
